<?php
$servername = "localhost";
$username = "id17867745_muhalwan";
$password = "Ayamgoreng12@";
$dbname = "id17867745_pweb";

// Create connection
$link = new mysqli($servername, $username, $password, $dbname);
// Check connection
if($link === false){
    die("ERROR: Could not connect. " . mysqli_connect_error());
}
$sql = "SELECT * FROM users";
$result = $link->query($sql);

if ($result->num_rows > 0) {
  // output data of each row
  while($row = $result->fetch_assoc()) {
    echo "id: " . $row["username"]. " - date created: " . $row["created_at"]. "<br>";
  }
} else {
  echo "0 results";
}
?>